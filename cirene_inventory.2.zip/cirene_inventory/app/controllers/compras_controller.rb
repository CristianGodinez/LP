class ComprasController < ApplicationController
  before_action :authenticate_admin!

  # GET /compras
  def index
    @productos = Producto.all
    @compra = Compra.new
  end

  # POST /compras
  def create
    @compra = Compra.new(compra_params)
    @productos = Producto.all  # Necesario para re-renderizar el index

    producto = Producto.find(@compra.producto_id)
    @compra.precio_total = @compra.cantidad * producto.precio

    # Validar stock
    if @compra.cantidad > producto.stock
      @compra.errors.add(:cantidad, "no puede ser mayor que el stock disponible (#{producto.stock})")
    end

    # Si hay errores o falla el guardado
    if @compra.errors.any? || !@compra.save
      render :index
    else
      redirect_to compras_path, notice: "Venta registrada correctamente."
    end
  end

  # GET /compras/historial
  def historial
    @ventas = Compra.includes(:producto).order(created_at: :desc)
  end

  private

  def compra_params
    params.require(:compra).permit(:producto_id, :cantidad)
  end
end
