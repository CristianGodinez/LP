class ReportesController < ApplicationController
  before_action :authenticate_admin!

  def index
    # Carga todos los productos para el filtro
    @productos = Producto.all

    # Si llega un producto_id por params, filtramos; si no, usamos todas las ventas
    ventas = if params[:producto_id].present?
               Compra.where(producto_id: params[:producto_id])
             else
               Compra.all
             end

    # Ventas por mes (unidades vendidas)
    @ventas_por_mes = ventas
      .group_by_month(:created_at, format: "%b %Y")
      .sum(:cantidad)

    # Ingresos por mes (total monetario)
    @ingresos_por_mes = ventas
      .group_by_month(:created_at, format: "%b %Y")
      .sum(:precio_total)
  end
end
