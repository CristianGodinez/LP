class Producto < ApplicationRecord
  has_many :compras, dependent: :destroy

  # Asociación para la imagen
  has_one_attached :imagen
end
