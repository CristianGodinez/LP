Rails.application.routes.draw do
  get "reportes/index"
  resources :compras do
    collection do
      get 'historial'
    end
  end
  resources :productos
  devise_for :users, skip: [:registrations, :passwords]

  get "up" => "rails/health#show", as: :rails_health_check

  root "compras#index"
  
  get "reportes", to: "reportes#index", as: :reportes
  get "reportes/exportar_pdf", to: "reportes#exportar_pdf", as: :exportar_pdf_reportes
  get "reportes/exportar_excel", to: "reportes#exportar_excel", as: :exportar_excel_reportes
end
