class ReportesController < ApplicationController
  require "prawn/table"

  before_action :authenticate_user!
  before_action :authorize_admin!

  def index
    @productos = Producto.all
    @ventas = filtrar_ventas

    # Filtros desplegables
    @clientes = Compra.distinct.pluck(:cliente).compact.sort
    @empleados = User.select(:id, :nombre, :apellido).order(:nombre)
  end

  def exportar_pdf
    @productos = Producto.all
    @ventas = filtrar_ventas

    pdf = Prawn::Document.new

    logo_path = Rails.root.join("app/assets/images/logo_cirene.png")
    if File.exist?(logo_path)
      pdf.image logo_path.to_s, width: 80, height: 80, at: [pdf.bounds.right - 90, pdf.bounds.top]
    end

    pdf.move_down 20
    pdf.text "Reporte de Ventas", size: 24, style: :bold, align: :center
    pdf.move_down 30

    data = [["Producto", "Cantidad", "Precio Total", "Fecha", "Cliente", "Empleado"]]
    @ventas.each do |venta|
      data << [
        venta.producto.nombre,
        venta.cantidad,
        "$#{venta.precio_total}",
        venta.created_at.strftime("%d/%m/%Y"),
        venta.cliente,
        venta.user ? "#{venta.user.nombre} #{venta.user.apellido}" : "—"
      ]
    end

    pdf.table(data, header: true, row_colors: ["F0F0F0", "FFFFFF"], width: 540)
    pdf.move_down 10
    pdf.text "Total recaudado: $#{@ventas.sum(&:precio_total)}", size: 14, style: :bold

    send_data pdf.render, filename: "reporte_ventas.pdf", type: "application/pdf", disposition: "inline"
  end

  def exportar_excel
    @productos = Producto.all
    @ventas = filtrar_ventas

    respond_to do |format|
      format.xlsx {
        response.headers['Content-Disposition'] = "attachment; filename=reporte_ventas.xlsx"
      }
    end
  end

  private

  def authorize_admin!
    redirect_to root_path, alert: "Acceso restringido a administradores." unless current_user&.admin?
  end

  def filtrar_ventas
    ventas = Compra.includes(:producto, :user).order(created_at: :desc)

    if params[:producto_id].present?
      ventas = ventas.where(producto_id: params[:producto_id])
    end

    if params[:fecha_inicio].present? && params[:fecha_fin].present?
      inicio = Date.parse(params[:fecha_inicio])
      fin = Date.parse(params[:fecha_fin])
      ventas = ventas.where(created_at: inicio.beginning_of_day..fin.end_of_day)
    end

    if params[:cliente].present?
      ventas = ventas.where("cliente LIKE ?", "%#{params[:cliente]}%")
    end

    if params[:empleado].present?
      nombre, apellido = params[:empleado].split(" ", 2)
      ventas = ventas.joins(:user)
                    .where(users: { nombre: nombre })
      ventas = ventas.where("users.apellido LIKE ?", "%#{apellido}%") if apellido.present?
    end


    ventas
  end
end
